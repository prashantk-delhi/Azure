# AZ-303 Online Lab List #
Lab files list and course module order (11/20/20).

**Module 05 Lab**

* Lab: Implementing Highly Available Azure IaaS Compute Architecture 

* Current file name: **Module_05_Lab.md**

* [https://aka.ms/303_Module_05_Lab](https://aka.ms/303_Module_05_Lab) 

* Previous file name: *Module_4_Lab.md*

**Module 06 Lab**

Lab title: Implementing and Configuring Azure Storage File and Blob Services

* Current file name: **Module_06_Lab.md**

* [https://aka.ms/303_Module_06_Lab](https://aka.ms/303_Module_06_Lab) 

* Previous file name: *Module_5_Lab.md*

**Module 10 Lab**

Lab title: Managing Azure Role-Based Access Control 

* Current file name: **Module_10_Lab.md**

* [https://aka.ms/303_Module_10_Lab](https://aka.ms/303_Module_10_Lab) 

* Previous file name: *Module_7_Lab.md*

**Module 12 Lab**

Lab title: Protecting Hyper-V VMs by using Azure Site Recovery

* Current file name: **Module_12_Lab_a.md**

* [https://aka.ms/303_Module_12_Lab](https://aka.ms/303_Module_12_Lab) 

* Previous file name: *Module_9_Lab.md*

**Module 14 lab (a)**

Lab title: Implementing an Azure App Service Web App with a Staging Slot 

* Current file name: **Module_14_Lab_a.md**

* [https://aka.ms/303_Module_14a_Lab](https://aka.ms/303_Module_14a_Lab) 

* Previous file name: *Module_12_Lab_a.md*

**Module 14 lab (b)**

Lab title: Configuring a Message-Based Integration Architecture

* Current file name: **Module_14_Lab_b.md**

* [https://aka.ms/303_Module_14b_Lab](https://aka.ms/303_Module_14b_Lab) 

* Previous file name: *Module_12_Lab_b.md*
