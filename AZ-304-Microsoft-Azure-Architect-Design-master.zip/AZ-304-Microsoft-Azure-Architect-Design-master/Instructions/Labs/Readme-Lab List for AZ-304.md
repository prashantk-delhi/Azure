
#AZ-304: Lab file names in GitHub 
 
**Source repo: [https://github.com/MicrosoftLearning/AZ-304-Microsoft-Azure-Architect-Design/](https://github.com/MicrosoftLearning/AZ-304-Microsoft-Azure-Architect-Design/)**


**Module 3 Lab**

Lab title: Migrating Hyper-V VMs to Azure by using Azure Migrate

- Current file name: **Module_3_Lab.md**
- Previous file name: LAB_02_Data Storage.md

**Module 4 Lab** 

Lab title: Managing Azure AD Authentication and Authorization

- Current file name: **Module_4_Lab.md**
- Previous file name: LAB_10_Security.md

**Module 6 Lab** 

Lab title: Implementing Azure SQL Database-Based Applications

- Current file name: **Module_6_Lab.md**
- Previous file name: LAB_03_Data Storage.md

**Module 13 Lab** 

Lab title: Implement Azure Logic Apps Integration with Azure Event Grid

- Current file name: **Module_13_Lab_a.md**
- Previous file name: LAB_04_Manage Compute_PaaS.md
